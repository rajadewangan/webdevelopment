<ul id="userMenu" class="list-group">
<li class="list-group-item"><a href="editProfile.php">Purchase</a></li>

<li class="list-group-item"><a href="userCart.php">Display Cart</a></li>
<li class="list-group-item"><a href="displayOrderMasterForCancelUser.php">Cancel Order</a></li>

<li class="list-group-item"><a href="userInbox.php"> Inbox</a></li>
<li class="list-group-item"><a href="complainForm.php"> Complain </a></li>
<li class="list-group-item"><a href="orderList.php"> Order History</a></li>
<li class="list-group-item"><a href="editProfile.php">Edit Profile</a></li>
  <li class="list-group-item"><a href="logout.php"> Logout</a></li>

</ul>