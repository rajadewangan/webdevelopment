<?php 
  include("header.php");
  @session_start();
?>
<div id="container"> 

   <div id='cartinfo'>
    <?php 
      $odid=$_REQUEST["order_id"];
      include("dbconnect.php");
      $usr=$_SESSION["uname"];

      $rsMain=mysqli_query($con,"select * from order_main where order_id='$odid'");
      $row=mysqli_fetch_array($rsMain);
      echo("<form method='get' action='updateStatus.php'>");
echo('<input type="hidden" name="order_id" value="' . $odid . '">');
echo('<select name="order_status">');
echo('<option value="Dispatched">Dispatched</option>');
echo('<option value="Shipped">Shipped</option>');
echo('<option value="Cancelled">Cancelled</option>');
echo('<option value="Returned">Returned</option>');
echo('<option value="Pending">Pending</option>');
echo('<option value="Received">Received</option>');

echo('</select></div>');
echo('<input type="submit" value="Update Status">');
echo("</form>");
      echo("<div id='adminOrderDetails'><div>");
      echo("Bill No : ".$row["order_id"] ."<br>");
      echo("Order Date : ".$row["order_date"] ."<br>");
      echo("Shipping Address : ".$row["shipping_address"] ."<br>");
      echo("Total Amount : ".$row["total_amount"] ."</div>");





      $sql="select ci.order_detail_id,ci.item_rate,ci.item_quantity,ii.item_name,ii.item_img from order_detail as ci,item_info as ii where ci.order_main_id='$odid' and ci.item_id=ii.item_id ";
      $rscart=mysqli_query($con,$sql) or die("Query Error -2");
      echo("<table border='2' id='displayCartInfoTable'>");
      echo("<tr><th>Sl.No. </th><th>Item Name </th><th>Image </th><th> Rate </th><th>Quantity </th><th> Amount</th> </tr>");
      $cnt=0;
      $total=0;
      while($row=mysqli_fetch_array($rscart))
      {
        $cnt++;
        echo("<tr>");
        echo("<td>");
        echo($cnt);
        echo("</td>");
        echo("<td>");
        echo($row["item_name"]);
        echo("</td>");

        echo("<td>");
        $img=".//collection//".$row['item_img'];
        echo("<img src='$img' width='50' height='50' border='1'>");
        echo("</td>");

        echo("<td>");
        echo($row["item_rate"]);
        echo("</td>");
        echo("<td>");
        echo($row["item_quantity"]);
        echo("</td>");
        $amnt=$row["item_rate"] * $row["item_quantity"];
        echo("<td>");
        echo($amnt);
        $total=$total + $amnt;
        echo("</td>");

     


        echo("</tr>");
      }
      echo("<tr><td colspan='5' align='right'>Total Amount : </td> <td colspan='2' >$total </td> </tr>");
      echo("</table>");



    ?>
   </div><!--end of cartinfo-->
   <!-- <a href='printOrder.php?amnt=<?=$total?>' id='placeOrder'>Print Bill</a> -->
    

</div><!--end of container--> 

<?php 
  include("footer.php");
?>