<ul id="adminMenu" class="list-group">
  <li class="list-group-item"><a href="categoryForm.php"> Create Category</a></li>
  <li class="list-group-item"><a href="itemForm.php">Create Item</a></li>
  <li class="list-group-item"><a href="newsForm.php">Create News</a></li>
  <li class="list-group-item"><a href="offerForm.php">Create Offers</a></li>
  <li class="list-group-item"><a href="complainList.php"> Inbox</a></li>
  <!-- <li class="list-group-item"><a href="adminComposeList.php"> Compose </a></li> -->
  <li class="list-group-item disabled" aria-disabled="true">Reports</li>
  <li class="list-group-item"><a href="adminOrderList.php"> Order List</a></li>
  <li class="list-group-item"><a href="customerList.php"> Customer List</a></li>
  <li class="list-group-item"><a href="categoryList.php"> Category List</a></li>
  <li class="list-group-item"><a href="itemList.php"> Item List</a></li>
  <li class="list-group-item"><a href="newsList.php"> News List</a></li>
  <li class="list-group-item"><a href="offerList.php"> Offer List</a></li>
</ul>